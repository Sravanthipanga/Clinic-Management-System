package com.sravanthi.rapidclinic.web.api;

import com.sravanthi.rapidclinic.domain.jpa.PatientEntity;
import com.sravanthi.rapidclinic.service.PatientService;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/patients")
public class PatientApiController {

    private final PatientService service;

    public PatientApiController(PatientService service) {
        this.service = service;
    }

    public static class CreatePatientRequest {
        @NotBlank public String fullName;
        @Min(0) public int age;
        public String phone;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public PatientEntity create(@RequestBody CreatePatientRequest req) {
        return service.create(req.fullName, req.age, req.phone);
    }

    @GetMapping
    public List<PatientEntity> list() {
        return service.list();
    }

    @GetMapping("/{id}")
    public PatientEntity get(@PathVariable Long id) {
        return service.getOrThrow(id);
    }
}
