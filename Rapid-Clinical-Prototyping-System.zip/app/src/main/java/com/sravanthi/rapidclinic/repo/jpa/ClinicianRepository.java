package com.sravanthi.rapidclinic.repo.jpa;

import com.sravanthi.rapidclinic.domain.jpa.ClinicianEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ClinicianRepository extends JpaRepository<ClinicianEntity, Long> { }
