package com.sravanthi.rapidclinic.repo.jpa;

import com.sravanthi.rapidclinic.domain.jpa.PatientEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PatientRepository extends JpaRepository<PatientEntity, Long> { }
