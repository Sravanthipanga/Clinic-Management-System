package com.sravanthi.rapidclinic.repo.mongo;

import com.sravanthi.rapidclinic.domain.mongo.PrescriptionDoc;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;

public interface PrescriptionRepository extends MongoRepository<PrescriptionDoc, String> {
    List<PrescriptionDoc> findByPatientId(Long patientId);
}
