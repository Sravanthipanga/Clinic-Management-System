package com.sravanthi.rapidclinic;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RapidClinicApplication {
    public static void main(String[] args) {
        SpringApplication.run(RapidClinicApplication.class, args);
    }
}
