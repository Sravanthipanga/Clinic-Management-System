package com.sravanthi.rapidclinic.service;

import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

/**
 * Rapid prototyping rule engine:
 * Keep rules simple and transparent so they can be iterated quickly with clinicians.
 */
@Service
public class PrototypeRuleEngine {

    public Map<String, Object> triage(Map<String, Object> input) {
        Map<String, Object> out = new HashMap<>();
        int age = asInt(input.get("age"), 0);
        boolean fever = asBool(input.get("fever"), false);
        int systolic = asInt(input.get("systolicBp"), 120);

        String risk = "LOW";
        if (age >= 65 && fever) risk = "HIGH";
        else if (systolic >= 180) risk = "HIGH";
        else if (fever) risk = "MEDIUM";

        out.put("risk", risk);
        out.put("explain", "Derived from simple prototype rules (age/fever/bp).");
        return out;
    }

    private int asInt(Object v, int def) {
        if (v == null) return def;
        if (v instanceof Number) return ((Number) v).intValue();
        try { return Integer.parseInt(v.toString().trim()); } catch (Exception e) { return def; }
    }

    private boolean asBool(Object v, boolean def) {
        if (v == null) return def;
        if (v instanceof Boolean) return (Boolean) v;
        return Boolean.parseBoolean(v.toString().trim());
    }
}
