package com.sravanthi.rapidclinic.service;

import com.sravanthi.rapidclinic.domain.jpa.PatientEntity;
import com.sravanthi.rapidclinic.repo.jpa.PatientRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PatientService {

    private final PatientRepository repo;

    public PatientService(PatientRepository repo) {
        this.repo = repo;
    }

    public PatientEntity create(String fullName, int age, String phone) {
        return repo.save(new PatientEntity(fullName, age, phone));
    }

    public List<PatientEntity> list() {
        return repo.findAll();
    }

    public PatientEntity getOrThrow(Long id) {
        return repo.findById(id).orElseThrow(() -> new IllegalArgumentException("Patient not found: " + id));
    }
}
