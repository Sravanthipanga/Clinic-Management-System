package com.sravanthi.rapidclinic.domain.mongo;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.Instant;
import java.util.Map;

@Document(collection = "prescriptions")
public class PrescriptionDoc {

    @Id
    private String id;

    private Long patientId;
    private Long clinicianId;

    private String medication;
    private String directions;

    private Instant createdAt = Instant.now();

    // Optional structured metadata for rapid prototyping
    private Map<String, Object> tags;

    public PrescriptionDoc() { }

    public PrescriptionDoc(Long patientId, Long clinicianId, String medication, String directions, Map<String, Object> tags) {
        this.patientId = patientId;
        this.clinicianId = clinicianId;
        this.medication = medication;
        this.directions = directions;
        this.tags = tags;
    }

    public String getId() { return id; }
    public Long getPatientId() { return patientId; }
    public Long getClinicianId() { return clinicianId; }
    public String getMedication() { return medication; }
    public String getDirections() { return directions; }
    public Instant getCreatedAt() { return createdAt; }
    public Map<String, Object> getTags() { return tags; }

    public void setPatientId(Long patientId) { this.patientId = patientId; }
    public void setClinicianId(Long clinicianId) { this.clinicianId = clinicianId; }
    public void setMedication(String medication) { this.medication = medication; }
    public void setDirections(String directions) { this.directions = directions; }
    public void setTags(Map<String, Object> tags) { this.tags = tags; }
}
