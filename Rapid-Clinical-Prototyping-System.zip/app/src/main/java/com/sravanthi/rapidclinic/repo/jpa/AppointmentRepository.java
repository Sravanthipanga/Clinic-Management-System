package com.sravanthi.rapidclinic.repo.jpa;

import com.sravanthi.rapidclinic.domain.jpa.AppointmentEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AppointmentRepository extends JpaRepository<AppointmentEntity, Long> { }
