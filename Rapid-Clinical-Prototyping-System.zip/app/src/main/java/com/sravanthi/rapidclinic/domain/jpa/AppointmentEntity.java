package com.sravanthi.rapidclinic.domain.jpa;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "appointments")
public class AppointmentEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    private PatientEntity patient;

    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    private ClinicianEntity clinician;

    @Column(nullable = false)
    private LocalDateTime scheduledAt;

    @Column(length = 32)
    private String status; // scheduled, completed, cancelled

    protected AppointmentEntity() { }

    public AppointmentEntity(PatientEntity patient, ClinicianEntity clinician, LocalDateTime scheduledAt, String status) {
        this.patient = patient;
        this.clinician = clinician;
        this.scheduledAt = scheduledAt;
        this.status = status;
    }

    public Long getId() { return id; }
    public PatientEntity getPatient() { return patient; }
    public ClinicianEntity getClinician() { return clinician; }
    public LocalDateTime getScheduledAt() { return scheduledAt; }
    public String getStatus() { return status; }

    public void setScheduledAt(LocalDateTime scheduledAt) { this.scheduledAt = scheduledAt; }
    public void setStatus(String status) { this.status = status; }
}
