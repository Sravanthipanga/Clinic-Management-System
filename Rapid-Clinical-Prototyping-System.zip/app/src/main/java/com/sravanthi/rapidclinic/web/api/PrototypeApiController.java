package com.sravanthi.rapidclinic.web.api;

import com.sravanthi.rapidclinic.service.PrototypeRuleEngine;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/prototype")
public class PrototypeApiController {

    private final PrototypeRuleEngine engine;

    public PrototypeApiController(PrototypeRuleEngine engine) {
        this.engine = engine;
    }

    @PostMapping("/triage")
    public Map<String, Object> triage(@RequestBody Map<String, Object> input) {
        return engine.triage(input);
    }
}
