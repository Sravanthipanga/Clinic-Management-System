# Rapid Clinical Prototyping System

A Spring Boot project for rapidly prototyping clinic workflows and simple, explainable clinical decision logic.

## What it includes
- **MVC dashboards** (Thymeleaf): `/admin`, `/clinician`
- **REST APIs**:
  - `GET/POST /api/patients`
  - `POST /api/prototype/triage` (lightweight rule engine)
- **Persistence**
  - MySQL via Spring Data JPA (core clinic entities)
  - MongoDB via Spring Data MongoDB (flexible clinical documents like prescriptions)

## Run locally
1. Start MySQL + MongoDB locally (or set env vars shown in `app/src/main/resources/application.properties`)
2. From `app/`:
   - `./mvnw spring-boot:run`

## Why this exists
Clinical product teams often need to validate workflows and rule logic quickly.
This repo focuses on speed of iteration while keeping outputs transparent and testable.
