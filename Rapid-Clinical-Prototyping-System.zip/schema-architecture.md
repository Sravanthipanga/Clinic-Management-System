# Schema & Architecture

## 1) Architecture summary

This application is a Spring Boot backend designed for **rapid clinical prototyping**. It combines MVC pages (Thymeleaf) for quick dashboards and REST APIs for programmatic workflows. Requests enter through controllers, flow into a service layer that holds business logic and prototype clinical rules, and then persist through repositories.

Two data stores are used to match typical healthcare needs: **MySQL** stores structured relational entities (patients, clinicians, appointments) using JPA, while **MongoDB** stores flexible clinical documents (e.g., prescriptions with optional tags/metadata) using document models. This split makes it easy to prototype new clinical data shapes without repeatedly changing relational schemas.

## 2) Numbered flow of data and control

1. A user opens an MVC dashboard (`/admin` or `/clinician`) or calls a REST endpoint under `/api/...`.
2. Spring MVC routes the request to the correct controller (MVC controller for Thymeleaf pages, REST controller for JSON).
3. The controller validates basic inputs and calls the corresponding service method.
4. The service layer applies business rules (e.g., patient creation) and prototype logic (e.g., triage risk scoring).
5. For relational data, the service calls a JPA repository that reads/writes MySQL tables.
6. For clinical documents (prescriptions/notes), the service calls a Mongo repository that reads/writes MongoDB documents.
7. The controller returns the response as HTML (Thymeleaf) or JSON (REST), and the same flow repeats for the next navigation/event.
